﻿/*! jQuery Custom Tooltip v1.0 | Cristiano M. Dias | 16/09/2019 */
(function ($) {
    $.fn.csttp = function (options) {
        self = this;

        if (typeof (options) != 'undefined' && options != null) {
            $.extend(parameters, options);
        }

        return self.each(function (index) {
            var target = $(this);

            methods.initialSetup(target);

            methods.renderFor(target);
        });
    };

    var self = null;
    var parameters = {
        content: null,
        isHtmlContent: false,
        showTooltipEventNames: null,
        hideTooltipEventNames: null,
        hideOnTooltipClick: true
    };
    var methods = {
        generateId: function () {
            return Math.floor(Math.random() * 57654577);
        },
        initialSetup: function (target) {
            var newCsttpId = 'csttp' + methods.generateId();

            target.css({ position: 'relative' }).data('rel-csttp', newCsttpId);

            if (parameters.showTooltipEventNames) {
                eval('target.on({' + parameters.showTooltipEventNames.join(' ') + ' : function (e) { methods.setPosition($(this), newCsttpId); methods.setCsttpVisibility($(this), true); } });');
            } else { //Defaults to...
                target.on({ 'focus': function (e) { methods.setPosition($(this), newCsttpId); methods.setCsttpVisibility($(this), true); } });
            }

            if (parameters.hideTooltipEventNames) {
                eval('target.on({' + parameters.hideTooltipEventNames.join(' ') + ' : function (e) { methods.setPosition($(this), newCsttpId); methods.setCsttpVisibility($(this), false); } });');
            } else { //Defaults to...
                target.on({ 'focusout': function (e) { methods.setPosition($(this), newCsttpId); methods.setCsttpVisibility($(this), false); } });
            }

        },
        renderFor: function (target) {
            var csttp = $('<span />')
                .addClass("csttpShape")
                .attr('id', target.data('rel-csttp'));

            if (parameters) {
                if (parameters.content) {
                    if (parameters.isHtmlContent) {
                        csttp.html(parameters.content);
                    } else {
                        csttp.text(parameters.content);
                    }
                }

                if (parameters.hideOnTooltipClick) {
                    csttp.on('click', function (e) {
                        $(this).slideUp();
                    });
                }
            }

            $(document.body).append(csttp);
        },
        setPosition: function (target, csttpId) {
            target = $(target);
            var csttp = $('#' + csttpId);
            var doc = $(document);

            //var horizMargin = 4;
            //var vertMargin = 6;

            var horizMargin = 12;
            var vertMargin = 6;

            var scrWidth = doc.width();
            var scrHeight = doc.height();

            var targetOffset = target.offset();
            var targetLeft = targetOffset.left;
            var targetTop = targetOffset.top;
            var targetHeight = target.height();
            var targetWidth = target.width();

            //var csttpOffset = csttp.offset();
            var csttpHeight = csttp.height();
            var csttpWidth = csttp.width();
            var csttpLeft = 0;
            var csttpTop = 0;

            //Does the csttp fit on the target's right side?
            if (targetWidth + targetLeft + csttpWidth + horizMargin <= scrWidth) {
                csttpLeft = targetLeft + targetWidth + horizMargin;

                //Can the csttp be vertically aligned to the target's top?
                //Does the screen have sufficient vertical space to fit this?
                if (scrHeight - targetTop >= csttpHeight + vertMargin) {
                    csttpTop = targetTop;
                }
                else { //Ok, so align it vertically so the csttp's bottom is aligned to target's bottom
                    csttpTop = scrHeight - csttpHeight - vertMargin;
                }
            }
            //If it doesn't, does the csttp fit under the target?
            //else if (targetHeight + csttpHeight + vertMargin <= scrHeight) {
            else if (targetTop + targetHeight + csttpHeight <= scrHeight) {
                csttpTop = targetTop + targetHeight + vertMargin;

                //Can the csttp be horizontally aligned according to target's left side?
                if (targetLeft + csttpWidth <= scrWidth) {
                    csttpLeft = targetLeft;
                }
                else { //Ok, so align it horizontally so the csttp's right is aligned to target's right
                    csttpLeft = targetLeft - Math.abs(csttpWidth - targetWidth) - horizMargin;
                }
            }//If it doesn't, does the csttp fit on the target's left side?
            else if (targetLeft - csttpWidth >= 0) { //0 means the left side of the screen
                csttpLeft = targetLeft - csttpWidth - horizMargin - 2;

                //Can the csttp be vertically aligned to the target's top?
                //Does the screen have sufficient vertical space to fit this?
                if (targetTop + csttpHeight + vertMargin <= scrHeight - targetTop) {
                    csttpTop = targetTop;
                }
                else { //Ok, so align it vertically so the csttp's bottom is aligned to target's bottom
                    csttpTop = scrHeight - csttpHeight - vertMargin - 3;
                }
            }
            else { //Ok, so the csttp will be positioned over the target
                csttpTop = targetTop + csttpHeight;

                //Can the csttp be horizontally aligned according to target's left side?
                if (targetLeft + csttpWidth <= scrWidth) {
                    csttpLeft = targetLeft;
                }
                else { //Ok, so align it horizontally so the csttp's right is aligned to target's right
                    csttpLeft = targetLeft - Math.abs(csttpWidth - targetWidth) - horizMargin;
                }
            }

            csttp.css({ 'left': csttpLeft + 'px', 'top': csttpTop + 'px' });
        },
        setCsttpVisibility: function (target, show) {
            var csttp = $('#' + $(target).data('rel-csttp'));

            if (show) {

                csttp.slideDown();

            }
            else {

                csttp.slideUp();

            }
        }
    };
}(window.jQuery));