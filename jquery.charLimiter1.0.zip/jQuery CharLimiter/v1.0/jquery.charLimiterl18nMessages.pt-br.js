/*! jQuery Character Limiter component messages - Portuguese/Brazil | Designed and developed by Cristiano M. Dias on July 2nd, 2015 */
window.CharLimiter_i18nMessages = {
	DefaultRemainingXCharactersLabel : 'Restam {0} caracteres'
}