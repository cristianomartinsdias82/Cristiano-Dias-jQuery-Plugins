/*! jQuery Character Limiter component messages - English/United States | Designed and developed by Cristiano M. Dias on July 2nd, 2015 */
window.CharLimiter_i18nMessages = {
	DefaultRemainingXCharactersLabel : '{0} characters remaining'
}