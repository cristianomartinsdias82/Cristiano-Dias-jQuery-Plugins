/*! jQuery Character Limiter v1.0 | Designed and implemented by Cristiano M. Dias on July 6th, 2015 */
window.CharLimiters = [];

(function ($) {
    
    var climiter = function () {
        var self = this;

        self.traceEnabled = false;
        self.targetElement = null;
        self.targetIsTextArea = false;
        self.assistantElement = null;
        self.currentCharactersQuantity = 0;
        self.remainingCharactersQuantity = 0;
        self.maxCharactersLimit = 0;
        self.maxCharactersLimitReachedCallback = null;
        self.maxCharactersLimitExceededCallback = null;
        self.createAssistantLabel = true;
        self.labelClass = null;
        self.labelPosition = null;
        self.labelTextFormat = null;
        self.init = function (target, options) {
            self.trace('init invoked');

            self.targetElement = target;

            //Validates arguments and selectors. (Not every html element works with this component, after all)
            if (!self.argumentsAreValid(options, target))
                return;

            //Set element events
            self.targetElement.on('keyup', self.charLimiter_KeyUp).on('blur', self.charLimiter_Blur);

            //Set element attributes
            if (self.targetElement.is('input[type="text"]')) {
                self.trace('targetElement.is(input)');
                self.targetElement.attr('maxlength', options.maxCharactersLimit);
            }

            //Fill global variables with external parameters
            self.maxCharactersLimit = self.remainingCharactersQuantity = options.maxCharactersLimit;
            self.maxCharactersLimitReachedCallback = options.maxCharactersLimitReachedCallback;
            self.maxCharactersLimitExceededCallback = options.maxCharactersLimitExceededCallback;
            self.createAssistantLabel = options.createAssistantLabel;
            self.labelClass = options.labelClass;
            self.labelPosition = options.labelPosition;
            self.labelTextFormat = options.labelTextFormat;
            self.traceEnabled = options.traceEnabled || self.traceEnabled;

            //Requests assistant label creation
            if (self.createAssistantLabel) {
                self.createLabel();
            }

            //Updates the label in UI
            self.refreshLabel();
        };
        self.argumentsAreValid = function (options, targetElement) {
            self.trace('argumentsAreValid invoked');

            self.targetIsTextArea = self.targetElement.is('textarea');
            if (!self.targetElement.is('input[type="text"]') && !self.targetIsTextArea)
                return false;

            if (options == null)
                return false;

            if (options.maxCharactersLimit <= 0)
                return false;

            return true;
        },
        self.charLimiter_KeyUp = function (e) {
            self.trace('charLimiter_KeyUp invoked');

            self.evaluate();
        },
        self.charLimiter_Blur = function (e) {
            self.trace('charLimiter_Blur invoked');

            self.evaluate();
        },
        self.trimExcess = function () {
            self.trace('trimExcess invoked');

            self.targetElement.val(self.targetElement.val().substring(0, self.maxCharactersLimit));
        };
        self.evaluate = function () {
            self.trace('evaluate invoked');

            self.currentCharactersQuantity = self.targetElement.val().length;
            self.remainingCharactersQuantity = self.computeRemainingCharactersQuantity();

            if (self.assistantElement != null) {
                self.refreshLabel();
            }

            if (self.currentCharactersQuantity == self.maxCharactersLimit) {
                if (self.maxCharactersLimitReachedCallback != null)
                    self.maxCharactersLimitReachedCallback(self.targetElement.val());
            }
            else if (self.currentCharactersQuantity > self.maxCharactersLimit) {
                self.trace('currentCharactersQuantity > maxCharactersLimit');
                if (self.maxCharactersLimitExceededCallback != null)
                    self.maxCharactersLimitExceededCallback(self.targetElement.val());

                self.trimExcess();
            }
        };
        self.computeRemainingCharactersQuantity = function () {
            self.trace('computeRemainingCharactersQuantity invoked');

            var result = self.maxCharactersLimit - self.currentCharactersQuantity;

            if (result < 0)
                return 0;

            return result;
        };
        self.createLabel = function () {
            self.trace('createLabel invoked');

            self.assistantElement = $('<label />');

            if (self.labelClass != null) {
                self.assistantElement.addClass(self.labelClass);
            }

            if (self.labelPosition == null) {
                self.placeLabelDefaultPosition();
            }
            else {
                if (self.targetIsTextArea) {
                    switch ($.trim(self.labelPosition.toLowerCase())) {
                        case 'top left':
                        case 'left top':
                            self.targetElement.before(self.assistantElement.attr('style', 'vertical-align:top'));

                            break;

                        case 'top right':
                        case 'right top':
                            self.targetElement.after(self.assistantElement.attr('style', 'vertical-align:top'));

                            break;

                        case 'bottom left':
                        case 'left bottom':
                            self.assistantElement.attr('style', 'vertical-align:bottom').insertBefore(self.targetElement);

                            break;

                        case 'bottom right':
                        case 'right bottom':
                            self.targetElement.after($('<br />')).after(self.assistantElement.attr('style', 'vertical-align:bottom'));

                            break;

                        case 'left':
                            self.labelPosition = 'left top';
                            self.createLabel();

                            break;

                        case 'top':
                            self.assistantElement.insertBefore(self.targetElement);
                            $('<br/>').insertAfter(self.assistantElement);

                            break;

                        case 'right':
                            self.labelPosition = 'right top';
                            self.createLabel();

                            break;

                        case 'bottom':
                        default:
                            self.placeLabelDefaultPosition();

                            break;
                    }
                }
                else {
                    switch ($.trim(self.labelPosition.toLowerCase())) {
                        case 'top':
                            self.assistantElement.insertBefore(self.targetElement);
                            $('<br/>').insertAfter(self.assistantElement);

                            break;

                        case 'right':
                            self.assistantElement.insertAfter(self.targetElement);

                            break;

                        case 'left':
                            self.assistantElement.insertBefore(self.targetElement);

                            break;

                        case 'bottom':
                        default:
                            self.placeLabelDefaultPosition();

                            break;
                    }
                }
            }
        };
        self.refreshLabel = function () {
            self.trace('refreshLabel invoked');

            if (self.labelTextFormat != null) {
                self.assistantElement.html(self.labelTextFormat.replace('{0}', self.remainingCharactersQuantity));
            }
            else {
                var defaultText = self.remainingCharactersQuantity + " characters remaining";
                if (window.CharLimiter_i18nMessages != null) {
                    defaultText = window.CharLimiter_i18nMessages.DefaultRemainingXCharactersLabel.replace('{0}', self.remainingCharactersQuantity);
                }

                self.assistantElement.html(defaultText);
            }
        };
        self.placeLabelDefaultPosition = function () {
            var br = $('<br/>');
            br.insertAfter(self.targetElement);
            self.assistantElement.insertAfter(br);
        }
        self.trace = function (message) {
            if (self.traceEnabled) {
                console.log(message);
            }
        };
    }

    /*
    @Creates the character limiter control
    @Options internal arguments:
    -maxCharactersLimit: maximum allowed characters quantity
    -maxCharactersLimitReachedCallback: callback function that is fired when maximum characters quantity is reached
    -maxCharactersLimitExceededCallback: callback function that is fired when maximum characters quantity is exceeded
    -createAssistantLabel: whether creates an informative remaining characters label when typing or not
    -labelClass: if createAssistantLabel argument is true, sets the label's css class
    -labelPosition: if createAssistantLabel argument is true, sets the informative label's position, related to the target control
    -labelTextFormat: if createAssistantLabel argument is true, sets the informative label's text format. The token {0} should exist in this argument in order to work correctly
    -traceEnabled: if traceEnabled argument is true, logs all component's activities to the browser console pane
    NOTES: This plug-in currently applies to <input type='text' /> and <textarea/> html controls only
    Also, an integer major than zero number must be informed as the maximum allowed characters quantity
    */
    $.fn.charLimiter = function (options) {

        //Loop for jQuery multitarget selectors
        $(this).each(function (idx, ctrl) {
            var newLength = window.CharLimiters.push(new climiter());
            window.CharLimiters[newLength - 1].init($(ctrl), options);
        });
    }
})(jQuery);