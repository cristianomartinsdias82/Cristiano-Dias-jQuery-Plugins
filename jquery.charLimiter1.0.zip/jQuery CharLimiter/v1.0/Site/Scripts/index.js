/// <reference path="jquery-1.11.2.min.js" />
/// <reference path="jquery.charLimiter-1.0.js" />
$(function (e) {
    var options = {
        maxCharactersLimit: 10,
        maxCharactersLimitReachedCallback: onMaxCharactersLimitReachedCallback,
        maxCharactersLimitExceededCallback: onMaxCharactersLimitExceededCallback,
        createAssistantLabel: true,
        traceEnabled:false,
        labelClass: 'labelDisclaimer',
        labelTextFormat: null// '{0}' //,  //'{0} characters remaining' /* (set null for default i18n messages)*/
        //labelPosition: 'top' //compatible with input[type=text] and textarea controls
        //labelPosition: 'bottom' //compatible with input[type=text] and textarea controls
        //labelPosition: 'right' //compatible with input[type=text] and textarea controls
        //labelPosition: 'left' //compatible with for input[type=text] and textarea controls
        //labelPosition: 'left top' //compatible with textarea control only!
        //labelPosition: 'left bottom' //compatible with textarea control only!
        //labelPosition: 'right top' //compatible with textarea control only!
        //labelPosition: 'right bottom' //compatible with textarea control only!
    };

    //WORKS GREAT!
    //$('#txtFullName').charLimiter(options);
    //$('#txtPersonalDescription').charLimiter(options);
    //$('#txtAnnotations').charLimiter(options);

    //WORKS GREAT!
    //$('#txtFullName,#txtPersonalDescription,#txtAnnotations').charLimiter(options);

    //WORKS GREAT!
    //$('.limitedCharField').charLimiter(options);

    //WORKS GREAT!
    $('textarea, input[type="text"]').charLimiter(options);

    //Selector to undeclared controls >>> NOTHING HAPPENS! THAT'S GREAT!
    //$('#teste, .nonExistentClass').charLimiter(options);

    //Selector to null >>> NOTHING HAPPENS! THAT'S GREAT!
    //$(null).charLimiter(options);

    //Selector to an invalid control >>> NOTHING HAPPENS! THAT'S GREAT!
    $('[type=submit]').charLimiter(options);
});

var onMaxCharactersLimitReachedCallback = function (input) {
    console.log('onMaxCharactersLimitReachedCallback invoked');
    console.log('input = ' + input);
};

var onMaxCharactersLimitExceededCallback = function (attemptedInput) {
    console.log('onMaxCharactersLimitExceededCallback invoked');
    console.log('attemptedInput = ' + attemptedInput);
};