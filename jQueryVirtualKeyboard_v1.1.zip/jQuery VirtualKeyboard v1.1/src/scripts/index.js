(function($,window,document) {
    $('[data-role="vk"]').vk({
        //hideVkOnOkClick: false,
        //maxAllowedCharacters: 6,
        //onOkClick: function (e) {
        //    var target = $('#' + $(e.target).data('targetId'));

        //    alert(target.attr('value'));
        //}
    });
}(window.jQuery, window, document));