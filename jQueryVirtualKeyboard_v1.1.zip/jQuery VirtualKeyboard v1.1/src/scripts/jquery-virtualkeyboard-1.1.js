/*! jQuery Virtual Keyboard v1.1 | Cristiano M. Dias | 03/07/2016 */
(function ($) {
    $.fn.vk = function (options) {
        self = this;

        if (typeof (options) != 'undefined' && options != null) {
            $.extend(parameters, options);
        }

        return self.each(function (index) {
            var target = $(this);

            methods.initialSetup(target);

            methods.renderFor(target);
        });
    };

    var self = null;
    var parameters = {
        hideVkOnOkClick: true,
        maxAllowedCharacters: 10,
        onOkClick: null,
        onIllegalInputAttempt: null
    };
    var numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    var methods = {
        generateId: function () {
            return Math.floor(Math.random() * 57654577);
        },
        initialSetup: function (target) {
            var newVkId = 'vk' + methods.generateId();
            var newTargetId = 'txtPass' + methods.generateId();

            if (!target.is(':password')) {
                target.attr('type', 'password');
            }
            target.attr('value', '').css({ position: 'relative' }).data('rel-vk', newVkId).attr('id', newTargetId).attr('readonly', 'readonly').on({
                'focus': function (e) { methods.setPosition($(this), newVkId); methods.setVkVisibility($(this), true); },
                'keypress': function (e) {
                    if (parameters.onIllegalInputAttempt != null) {
                        e.preventDefault();
                        parameters.onIllegalInputAttempt(e);
                    }
                    else {
                        methods.preventDirectInteraction(e);
                    }
                },
                'paste': function (e) {
                    if (parameters.onIllegalInputAttempt != null) {
                        e.preventDefault();
                        parameters.onIllegalInputAttempt(e);
                    }
                    else {
                        methods.preventDirectInteraction(e);
                    }
                }
            });
        },
        renderFor: function (target) {
            var vk = $('<span />').addClass("vkShape").attr('id', target.data('rel-vk')).data('rel-passInput', target.attr('id'));
            var letterKeysContainer = $('<ul />').addClass("letterKeys").addClass("keyContainer");
            var aKeyItem = $('<li />');
            var aKey = $('<a href="#" />');

            for (var letterIndex = 0; letterIndex < letters.length; letterIndex++) {
                var letter = letters[letterIndex];

                var keyItem = aKeyItem.clone();
                if (typeof (letter.rowClass) != 'undefined' && letter.rowClass != null) {
                    keyItem.addClass(letter.rowClass);
                }

                var key = aKey.clone().data('targetId', target.attr('id'));
                if (typeof (letter.keyClass) != 'undefined' && letter.keyClass != null) {
                    key.addClass(letter.keyClass);
                }

                if (typeof (letter.onClick) != 'undefined' && letter.onClick != null) {
                    key.on('click', letter.onClick);
                }
                else {
                    key.on('click', function (e) {
                        e.preventDefault();
                        if (parameters.maxAllowedCharacters > 0) {
                            if (target.attr('value').length == parameters.maxAllowedCharacters) {
                                return;
                            }
                        }

                        target.attr('value', target.attr('value') + $(this).data('key'));
                    });
                }

                key.attr('data-key', letter.key).html(letter.key).on({
                    'mousedown': function (e) {
                        $('a[data-key]').addClass('hiddenKey');
                    },
                    'mouseup': function (e) {
                        $('a[data-key]').removeClass('hiddenKey');
                    }
                }).appendTo(keyItem);

                letterKeysContainer.append(keyItem);
            }

            letterKeysContainer.appendTo(vk);

            var numberKeysContainer = $('<ul />').addClass("numericKeys").addClass("keyContainer");
            var numbers = methods.getShuffledNumbers();
            var totalNumberKeySlots = 12;
            var emptySlots = [9, 11];
            var number = 0;
            var totalNumbers = numbers.length;

            for (var i = 0; i < totalNumberKeySlots; i++) {
                var keyItem = aKeyItem.clone();

                if (emptySlots.indexOf(i) == -1) {
                    number = numbers.pop();
                    aKey.clone().data('targetId', target.attr('id')).attr('data-key', number).html(number).on({
                        'click': function (e) {
                            e.preventDefault();
                            if (typeof (parameters.maxAllowedCharacters) != 'undefined' && parameters.maxAllowedCharacters > 0) {
                                if (target.attr('value').length == parameters.maxAllowedCharacters) {
                                    return;
                                }

                                target.attr('maxlength', parameters.maxAllowedCharacters);
                            }

                            target.attr('value', target.attr('value') + $(this).data('key'));
                        },
                        'mousedown': function (e) {
                            $('a[data-key]').addClass('hiddenKey');
                        },
                        'mouseup': function (e) {
                            $('a[data-key]').removeClass('hiddenKey');
                        }
                    }).appendTo(keyItem);
                }

                numberKeysContainer.append(keyItem);
            }

            numberKeysContainer.appendTo(vk);

            $(document.body).append(vk);
        },
        getShuffledNumbers: function () {
            var shuffledNumbers = numbers.slice();
            var temp = null;
            var nextNumber = 0;

            for (var i = 0; i < 10; i++) {
                nextNumber = Math.floor(Math.random() * 10);
                temp = shuffledNumbers[i];
                shuffledNumbers[i] = shuffledNumbers[nextNumber];
                shuffledNumbers[nextNumber] = temp;
            }

            return shuffledNumbers;
        },
        preventDirectInteraction: function (e) {
            e.preventDefault();

            alert('The secret must be informed by using the virtual keyboard!');

            $('#' + $(e.target).data('rel-vk') + ' a[data-key]:first').focus();
        },
        onOkClick: function (e) {
            if (parameters.onOkClick != null) {
                try {
                    parameters.onOkClick(e);
                }
                catch (e) { console.log(e); }
            }
            else {
                e.preventDefault();

                var target = $('#' + $(e.target).data('targetId'));

                console.log('Informed data: ' + target.attr('value'));
            }

            if (parameters.hideVkOnOkClick) {
                var target = $('#' + $(e.target).data('targetId'));

                $('#' + target.data('rel-vk')).slideUp();
            }
        },
        onClearClick: function (e) {
            $('#' + $(e.target).data('targetId')).attr('value', '');
        },
        setPosition: function (target, vkId) {
            target = $(target);
            var vk = $('#' + vkId);
            var doc = $(document);

            var horizMargin = 4;
            var vertMargin = 6;

            var scrWidth = doc.width();
            var scrHeight = doc.height();

            var targetOffset = target.offset();
            var targetLeft = targetOffset.left;
            var targetTop = targetOffset.top;
            var targetHeight = target.height();
            var targetWidth = target.width();

            var vkOffset = vk.offset();
            var vkHeight = vk.height();
            var vkWidth = vk.width();
            var vkLeft = 0;
            var vkTop = 0;

            //Does the vk fit on the target's right side?
            if (targetWidth + targetLeft + vkWidth + horizMargin <= scrWidth) {
                vkLeft = targetLeft + targetWidth + horizMargin;

                //Can the vk be vertically aligned to the target's top?
                //Does the screen have sufficient vertical space to fit this?
                if (scrHeight - targetTop >= vkHeight + vertMargin) {
                    vkTop = targetTop;
                }
                else { //Ok, so align it vertically so the vk's bottom is aligned to target's bottom
                    vkTop = scrHeight - vkHeight - vertMargin;
                }
            }
                //If it doesn't, does the vk fit under the target?
                //else if (targetHeight + vkHeight + vertMargin <= scrHeight) {
            else if (targetTop + targetHeight + vkHeight <= scrHeight) {
                vkTop = targetTop + targetHeight + vertMargin;

                //Can the vk be horizontally aligned according to target's left side?
                if (targetLeft + vkWidth <= scrWidth) {
                    vkLeft = targetLeft;
                }
                else { //Ok, so align it horizontally so the vk's right is aligned to target's right
                    vkLeft = targetLeft - Math.abs(vkWidth - targetWidth) - horizMargin;
                }
            }//If it doesn't, does the vk fit on the target's left side?
            else if (targetLeft - vkWidth >= 0) { //0 means the left side of the screen
                vkLeft = targetLeft - vkWidth - horizMargin - 2;

                //Can the vk be vertically aligned to the target's top?
                //Does the screen have sufficient vertical space to fit this?
                if (targetTop + vkHeight + vertMargin <= scrHeight - targetTop) {
                    vkTop = targetTop;
                }
                else { //Ok, so align it vertically so the vk's bottom is aligned to target's bottom
                    vkTop = scrHeight - vkHeight - vertMargin - 3;
                }
            }
            else { //Ok, so the vk will be positioned over the target
                vkTop = targetTop + vkHeight;

                //Can the vk be horizontally aligned according to target's left side?
                if (targetLeft + vkWidth <= scrWidth) {
                    vkLeft = targetLeft;
                }
                else { //Ok, so align it horizontally so the vk's right is aligned to target's right
                    vkLeft = targetLeft - Math.abs(vkWidth - targetWidth) - horizMargin;
                }
            }

            vk.css({ 'left': vkLeft + 'px', 'top': vkTop + 'px' });
        },
        setVkVisibility: function (target, show) {
            var vk = $('#' + target.data('rel-vk'));

            if (show) {
                vk.slideDown();
            }
            else {
                vk.slideUp();
            }
        }
    };
    var letters = [{ key: 'q' }, { key: 'w' }, { key: 'e' }, { key: 'r' }, { key: 't' }, { key: 'y' }, { key: 'u' }, { key: 'i' }, { key: 'o' }, { key: 'p' }, { key: 'a', rowClass: 'secondRow' }, { key: 's' }, { key: 'd' }, { key: 'f' }, { key: 'g' }, { key: 'h' }, { key: 'j' }, { key: 'k' }, { key: 'l' }, { key: 'z', rowClass: 'thirdRow' }, { key: 'x' }, { key: 'c' }, { key: 'v' }, { key: 'b' }, { key: 'n' }, { key: 'm' }, { key: '_' }, { key: 'Clear', rowClass: 'fourthRow', keyClass: 'clearKey', onClick: methods.onClearClick }, { key: 'Ok', keyClass: 'enterKey', onClick: methods.onOkClick }];
}(window.jQuery));